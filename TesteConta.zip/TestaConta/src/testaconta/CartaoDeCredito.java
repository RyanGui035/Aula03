
package testaconta;


public class CartaoDeCredito {
    int numero;
    String dataValidade; 
    Cliente cliente;
}
