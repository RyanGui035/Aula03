package testaconta;
public class TestaConta {

    public static void main(String[] args) {
        // CRIANDO OBJETOS
        Conta referencia = new Conta();
        referencia.saldo = 1000.0;
        referencia.limite = 500.0;
        referencia.numero = 1; 

        System.out.println(referencia.saldo);
        System.out.println(referencia.limite);
        System.out.println(referencia.numero);
        
        
        
        Cliente cliente1 = new Cliente();
        Cliente cliente2 = new Cliente();
        
        cliente1.nome="Ryan";
        cliente1.codigo=1;
        cliente2.nome="Beatriz";
        cliente2.codigo=2;
        
        System.out.println(cliente1.nome);
        System.out.println(cliente1.codigo);
        System.out.println(cliente2.nome);
        System.out.println(cliente2.codigo);

        
        
        CartaoDeCredito cartao1 = new CartaoDeCredito();
        CartaoDeCredito cartao2 = new CartaoDeCredito();
        
        cartao1.numero=1;
        cartao1.dataValidade = "09/30";
        cartao2.numero=2;
        cartao2.dataValidade = "08/30";

        System.out.println(cartao1.numero);
        System.out.println(cartao1.dataValidade);
        System.out.println(cartao2.numero);
        System.out.println(cartao2.dataValidade);
       
        
        Agencia numeroBanco1 = new Agencia();
        Agencia numeroBanco2 = new Agencia();
        
        numeroBanco1.numero=05;
        numeroBanco1.UF= "DF";
        numeroBanco2.numero=07;
        numeroBanco2.UF= "GO";

        System.out.println(numeroBanco1.numero);
        System.out.println(numeroBanco1.UF);
        System.out.println(numeroBanco2.numero);
        System.out.println(numeroBanco2.UF);
        
        
        
    CartaoDeCredito cdc = new CartaoDeCredito();
    Cliente c = new Cliente();
    
    cdc.cliente = c;
    cdc.cliente.nome = "Ryan Guilherme";
        System.out.println("Nome: " + cdc.cliente.nome);
        
        }
    

}
