package testaconta;

public class Cliente {
        String nome;
        int codigo;
       
    }