package testaconta;
public class Agencia {
    int numero;
    String UF;
    
}
