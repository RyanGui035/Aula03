package testaconta;
public class Conta {
   double saldo;
   double limite = 500;
   int numero;
}

